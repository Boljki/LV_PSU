import numpy as np
import matplotlib.pyplot as plt
import matplotlib.image as mpimg
from sklearn.cluster import KMeans


image = mpimg.imread('example.png')
# ako je RGB slika → zadržava se boja
h, w, c = image.shape
# pretvaranje u (broj piksela, 3 boje)
X = image.reshape((-1, 3))
# broj klastera (boja)
k = 8
kmeans = KMeans(n_clusters=k, n_init=10)
kmeans.fit(X)
labels = kmeans.labels_
centers = kmeans.cluster_centers_
image_quantized = centers[labels].reshape(h, w, c)
plt.figure(1)
plt.title("Originalna slika")
plt.imshow(image)
plt.axis('off')
plt.figure(2)
plt.title(f"Kvantizirana slika (k={k})")
plt.imshow(image_quantized)
plt.axis('off')

plt.show()