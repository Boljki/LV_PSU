import numpy as np
import matplotlib.pyplot as plt
import matplotlib.image as mpimg
from sklearn import cluster

imageNew = mpimg.imread('example_grayscale.png')
# ako je RGB, pretvori u grayscale
if len(imageNew.shape) == 3:
    imageNew = np.mean(imageNew, axis=2)
X = imageNew.reshape((-1, 1))
# broj klastera
k = 10
k_means = cluster.KMeans(n_clusters=k, n_init=10)
k_means.fit(X)
values = k_means.cluster_centers_.squeeze()
labels = k_means.labels_
image_compressed = np.choose(labels, values)
image_compressed.shape = imageNew.shape
plt.figure(1)
plt.title("Original")
plt.imshow(imageNew, cmap='gray')
plt.figure(2)
plt.title(f"Kvantizacija (k={k})")
plt.imshow(image_compressed, cmap='gray')
plt.show()

#Povećanjem broja klastera slika postaje kvalitetnija, ali se smanjuje stupanj kompresije. 
#Za 10 klastera svaka vrijednost piksela može se predstaviti s 4 bita umjesto 8 bita, s tim duplo manje torši memoriju uz prihvatljiv gubitak kvalitete