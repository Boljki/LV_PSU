from sklearn import datasets
from sklearn.cluster import KMeans
import numpy as np
import matplotlib.pyplot as plt

def generate_data(n_samples, flagc):
    
    if flagc == 1:
        X, y = datasets.make_blobs(n_samples=n_samples, random_state=365)
        
    elif flagc == 2:
        X, y = datasets.make_blobs(n_samples=n_samples, random_state=148)
        transformation = [[0.60834549, -0.63667341], [-0.40887718, 0.85253229]]
        X = np.dot(X, transformation)
        
    elif flagc == 3:
        X, y = datasets.make_blobs(
            n_samples=n_samples,
            centers=4,
            cluster_std=[1.0, 2.5, 0.5, 3.0],
            random_state=148
        )

    elif flagc == 4:
        X, y = datasets.make_circles(n_samples=n_samples, factor=.5, noise=.05)
        
    elif flagc == 5:
        X, y = datasets.make_moons(n_samples=n_samples, noise=.05)
    
    return X
n_samples = 500
k = 3
for flagc in range(1, 6):
    
    X = generate_data(n_samples, flagc)
    
    kmeans = KMeans(n_clusters=k, n_init=10)
    labels = kmeans.fit_predict(X)
    centers = kmeans.cluster_centers_
    

    plt.figure(figsize=(5,5))
    plt.scatter(X[:, 0], X[:, 1], c=labels, cmap='viridis', s=15)
    plt.scatter(centers[:, 0], centers[:, 1], c='red', s=150, marker='X')
    
    plt.title(f"Flagc = {flagc}")
    plt.xlabel("x1")
    plt.ylabel("x2")

plt.show()
X = generate_data(n_samples, 1)  

inertia = []
K_range = range(1, 21)

for k in K_range:
    kmeans = KMeans(n_clusters=k, n_init=10)
    kmeans.fit(X)
    inertia.append(kmeans.inertia_)
plt.figure()
plt.plot(K_range, inertia, marker='o')
plt.xlabel("Broj klastera (k)")
plt.ylabel("Kriterijska funkcija (inertia)")
plt.title("Elbow metoda - određivanje optimalnog k")
plt.grid(True)
plt.show()

#povecanjem broja klastera funkcija opada
#Optimalan broj klastera mozemo odredit pomocu elbow metode na način da tražimo točku  na grafu gdje krivulja naglo mijenja nagib