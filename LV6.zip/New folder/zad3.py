from sklearn import datasets
import matplotlib.pyplot as plt
from scipy.cluster.hierarchy import dendrogram, linkage

X, y = datasets.make_blobs(n_samples=500, random_state=365)
Z = linkage(X, method='ward')  
plt.figure(figsize=(10, 5))
dendrogram(Z)
plt.title("Dendrogram")
plt.xlabel("Podaci")
plt.ylabel("Udaljenost")
plt.show()

#promjenom metoda u linkage dijelu, mijenjaju se klasteri (spajaju se u drugacijem redosljedu) i udaljenosti 
#pomocu ward metode najbolje se vide prikazani rezultati s obzirom na velik broj podataka djeluje najurednije u odnosu na ostale metode
#ward metoda - klasteri jasno odvojeni, single - klasteri se spajaju po najblizim tockama, complete - gleda najudaljenije tocke, average - koristi prosjek udaljenosti