import numpy as np
from tensorflow import keras
from tensorflow.keras import layers
from matplotlib import pyplot as plt
from sklearn.metrics import confusion_matrix, ConfusionMatrixDisplay

# MNIST podatkovni skup
(x_train, y_train), (x_test, y_test) = keras.datasets.mnist.load_data()

# =========================================================
# 1. Prikaz nekoliko slika iz train skupa
# =========================================================

plt.figure(figsize=(10, 5))

for i in range(10):
    plt.subplot(2, 5, i + 1)
    plt.imshow(x_train[i], cmap='gray')
    plt.title(f"Label: {y_train[i]}")
    plt.axis('off')

plt.tight_layout()
plt.show()

# =========================================================
# Skaliranje vrijednosti piksela na raspon [0,1]
# =========================================================

x_train_s = x_train.astype("float32") / 255
x_test_s = x_test.astype("float32") / 255

# Slike 28x28 piksela se predstavljaju vektorom od 784 elementa
x_train_s = x_train_s.reshape(60000, 784)
x_test_s = x_test_s.reshape(10000, 784)

# Kodiraj labele (0, 1, ... 9) one hot encoding-om
y_train_s = keras.utils.to_categorical(y_train, 10)
y_test_s = keras.utils.to_categorical(y_test, 10)

# =========================================================
# 2. Kreiranje neuronske mreže
# =========================================================

model = keras.Sequential()

# Ulazni + prvi skriveni sloj
model.add(layers.Dense(128, activation='relu', input_shape=(784,)))

# Drugi skriveni sloj
model.add(layers.Dense(64, activation='relu'))

# Izlazni sloj
model.add(layers.Dense(10, activation='softmax'))

# Prikaz strukture mreže
model.summary()

# =========================================================
# 3. Definiranje procesa učenja
# =========================================================

model.compile(
    optimizer='adam',
    loss='categorical_crossentropy',
    metrics=['accuracy']
)

# =========================================================
# 4. Treniranje mreže
# =========================================================

history = model.fit(
    x_train_s,
    y_train_s,
    epochs=10,
    batch_size=32,
    validation_split=0.1
)

# =========================================================
# 5. Evaluacija mreže
# =========================================================

train_loss, train_acc = model.evaluate(x_train_s, y_train_s, verbose=0)
test_loss, test_acc = model.evaluate(x_test_s, y_test_s, verbose=0)

print(f"\nTočnost na train skupu: {train_acc:.4f}")
print(f"Točnost na test skupu: {test_acc:.4f}")

# =========================================================
# 6. Matrica zabune - TRAIN
# =========================================================

y_train_pred = model.predict(x_train_s)
y_train_pred_classes = np.argmax(y_train_pred, axis=1)

cm_train = confusion_matrix(y_train, y_train_pred_classes)

plt.figure(figsize=(8, 8))
disp_train = ConfusionMatrixDisplay(confusion_matrix=cm_train)
disp_train.plot(cmap='Blues')
plt.title("Matrica zabune - Train skup")
plt.show()

# =========================================================
# 7. Matrica zabune - TEST
# =========================================================

y_test_pred = model.predict(x_test_s)
y_test_pred_classes = np.argmax(y_test_pred, axis=1)

cm_test = confusion_matrix(y_test, y_test_pred_classes)

plt.figure(figsize=(8, 8))
disp_test = ConfusionMatrixDisplay(confusion_matrix=cm_test)
disp_test.plot(cmap='Blues')
plt.title("Matrica zabune - Test skup")
plt.show()

# =========================================================
# 8. Pogrešno klasificirani primjeri
# =========================================================

wrong = np.where(y_test != y_test_pred_classes)[0]

plt.figure(figsize=(12, 8))

for i, index in enumerate(wrong[:10]):
    plt.subplot(2, 5, i + 1)

    plt.imshow(x_test[index], cmap='gray')

    plt.title(
        f"Stvarno: {y_test[index]}\nPredikcija: {y_test_pred_classes[index]}"
    )

    plt.axis('off')

plt.tight_layout()
plt.show()

#Matrica zabune pokazuje da model vecinu znamenki zapravo tocno prepoznaje, uz manji broj greska najvise grijesi na znamenkama slicnog oblika poput 3 i 9. To dokazuje da je model vrlo tocan uz manji problem klasifikacije na temelju slicnosti znamenki.